# BmiCalculator

BMI Calculator in Python

You need to have python(>=3.0) installed.

1. Run the bmi_engine.py class.
2. Input the rquired values (Gender, Age, Height, Weight).


# BmiCalculator will tell you...
Your BMI and which category you belong.

Minimum and maximum weight of your height.

Body FAT percentage.
